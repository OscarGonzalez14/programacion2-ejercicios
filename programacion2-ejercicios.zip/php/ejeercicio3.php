<?php
/*programa que recibe el radio de un circulo y devuelve el perimetro y el area*/
$radio=readline("Ingrese el radio del circulo : ");//Se le pide al usuario que introduzca el radio del circulo
//     La funcion readline captura los datos ingresados por el usuario

$perimetro=2*pi()*$radio;
$area=pi()*pow($radio,2);

echo "El perimetro del circulo es: ".$perimetro."\n";//Se muestran los resultados
echo "El area del circulo es: ".$area."\n";


?>
