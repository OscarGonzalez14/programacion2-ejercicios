<?php

//
class ValorPi
{
	// creamos la funcion readline
    function readline()
    {
		
        return rtrim(fgets(STDIN));
        
    }
    //function pi()
    
}

$Dato = new ValorPi($nIngresado);

$nIngresado = "Ingrese un numero para calcular Pi: ";
echo $nIngresado;
$nIngresado = $Dato->readline();
$nIngresado = (int)$nIngresado; //Si el usuario ingresa numero decimal lo transforma a entero
$suma=0;
$contador=0;

// recorremos la funcion hasta el valor de nIngresado y se asignamos a la variable contador incrementando
for ($contador = 0; $contador <= $nIngresado; $contador++) {
	// La variable $resultado contiene la funcion de la suma infinta para calcular el valor de pi
    $resultado=4*(pow(-1,$contador)/(2*($contador)+1));
    $suma=$suma+$resultado;
}

echo "Cuando numero ingresado es: ".$nIngresado,"---> El valor de Pi es ", $suma,"\n";




?>
