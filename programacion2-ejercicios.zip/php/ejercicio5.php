<?php
$multiplicando=readline("Meta el multiplicando: ");
$multiplicador=readline("Meta el multiplicador: ");//se piden los datos al usuario


$resultado=0;// se inicializa la variable 

while($multiplicador>=1){  //se inicia el ciclo mientras
	if ($multiplicador%2 !=0){  //se aplica una condicion para ver si el multiplicador es par o impar.
		$resultado=$resultado+$multiplicando;// Si la condicion es verdadera se agraga a resultado
											//al resultado
	
		}
	$multiplicando *= 2;//duplicamos el multiplicando
	$multiplicador /= 2;//dividimos entre 2 multiplicado
	}
echo "el resultado es: $resultado\n";//mostramos el resultado
?>
