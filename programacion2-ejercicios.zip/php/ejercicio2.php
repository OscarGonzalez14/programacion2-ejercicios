<?php
 //Escriba un programa que muestre todas las combinaciones posibles al momento de lanzar dos dados de 6 caras.
 
for ($dado1 = 1; $dado1 <= 6; $dado1++) {  //ciclo for externo(Muestra los lados del dado1)
 
    for ($dado2 = 1; $dado2 <=6; $dado2++) { //ciclo for interno(Muestra los lados del dado2) 
        
        echo "$dado1 == $dado2\n"; //Muestra las combinaciones
    }
}
?>

