<?php
/*Programa que regresa un numero invertido
 * Oscar Antonio Gonzalez G01132991 */
 
$numero=readline("Digite un numero de tres cifras : ");//se solicita un numero al usuario
$invertido=0;
while ($numero>0) { //iniciamos el ciclo
		$digito = $numero%10; // con esto sacamos el ultimo digito del numero
		$numero = $numero-$digito;//
		$numero = $numero/10;
		$invertido = $invertido*10+$digito;
	}
	echo 'El numero ivertido es: ',$invertido;

?>
